﻿using Newtonsoft.Json;
using System.Data;
using Utility.Common;
using WeatherAPI.Models;
using WeatherAPI.Repository.Interfaces;

namespace WeatherAPI.Repository
{
    public class WeatherForecastRepository : IWeatherForecastRepository
    {
        public async Task<WeatherForecastModel> GetWeatherForecastAllAsync(string BaseUrl, string ApiKey, string URL)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    DataSet someDataSet = new DataSet();
                    //string appId = "1910dcfff68e3bb21522383f2bd868da";
                    client.BaseAddress = new Uri(BaseUrl);
                    var weatherResponse = await client.GetAsync($"{URL}lat=22.9977913&lon=72.5086396&appid={ApiKey}");
                    //weatherResponse.EnsureSuccessStatusCode();
                    var jsonContent = await weatherResponse.Content.ReadAsStringAsync();
                    var weatherForecast = JsonConvert.DeserializeObject<WeatherForecastModel>(jsonContent);
                    //DataTable dt= ConvertJsonToDt.ToDataTable(weatherForecast.list);
                     //DataTable dt = ConvertJsonToDt.ToMainDataTable(weatherForecast);
                  
                       
                    //someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(weatherForecast));
                    //DataTable dtcity = ConvertJsonToDt.ToMainDataTable(weatherForecast.city);
                    //someDataSet.Tables.Add(dt);
                    //someDataSet.Tables.Add(dtcity);
                    //foreach (var item in weatherForecast.list)
                    //{
                    //    someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(item.main));
                    //    someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(item.rain));
                    //    someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(item.weather));
                    //    someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(item.clouds));
                    //    someDataSet.Tables.Add(ConvertJsonToDt.ToMainDataTable(item.wind));

                    //}
                    return weatherForecast;
                }
                catch (HttpRequestException httpRequestException)
                {
                    return BadRequest($"Failed to fetch Weather Forecast from OpenWeather: {httpRequestException.Message}");
                }                
            }
        }

        public async Task<WeatherForecastModel> GetWeatherForecastForCityAsync(string BaseUrl, string ApiKey, string URL, string City)
        {
            using (var client = new HttpClient())
            {
                try
                {
                    DataSet someDataSet = new DataSet();
                    //string appId = "1910dcfff68e3bb21522383f2bd868da";
                    client.BaseAddress = new Uri(BaseUrl);
                    var weatherResponse = await client.GetAsync($"{URL}q={City}&appid={ApiKey}");
                    //weatherResponse.EnsureSuccessStatusCode();
                    var jsonContent = await weatherResponse.Content.ReadAsStringAsync();
                    var weatherForecast = JsonConvert.DeserializeObject<WeatherForecastModel>(jsonContent);
                    return weatherForecast;
                }
                catch (HttpRequestException httpRequestException)
                {
                    return BadRequest($"Failed to fetch Weather Forecast from OpenWeather: {httpRequestException.Message}");
                }
            }
        }

        private WeatherForecastModel BadRequest(string v)
        {
            throw new NotImplementedException();
        }
    }
}
