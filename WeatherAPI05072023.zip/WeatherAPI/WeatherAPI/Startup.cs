﻿using Microsoft.Extensions.Configuration;
using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Busniess.Services;
using WeatherAPI.Models;
using WeatherAPI.Repository;
using WeatherAPI.Repository.Interfaces;

namespace WeatherAPI
{
    public class Startup
    {
        private IWebHostEnvironment environment;
        private ConfigurationManager configuration;

        public Startup(IWebHostEnvironment environment, ConfigurationManager configuration)
        {
            this.environment = environment;
            this.configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<IWeatherForecastService, WeatherForecastService>();
            services.AddTransient<IWeatherForecastRepository, WeatherForecastRepository>();
            services.Configure<AppSettings>(configuration.GetSection("AppSettings"));
        }
    }
}
