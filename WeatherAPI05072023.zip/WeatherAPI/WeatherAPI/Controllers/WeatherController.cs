using Microsoft.AspNetCore.Mvc;
using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Busniess.Services;
using WeatherAPI.Models;
using WeatherAPI.Repository;

namespace WeatherAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherController : ControllerBase
    {
       
        private ILogger<WeatherController> Logger;
        private IWeatherForecastService WeatherForecastService { get; }
        public WeatherController(ILogger<WeatherController> logger, IWeatherForecastService weatherForecastService)
        {
            Logger = logger;
            WeatherForecastService = weatherForecastService;
        }

       // [HttpGet(Name = "GetWeatherForecast1")]        
        //public async Task<WeatherForecastModel> GetWeatherForecastAsync()
        //{
        //    var response = await WeatherForecastService.GetWeatherForecastAllAsync().ConfigureAwait(false);
        //    return response;
        //}
    }
}