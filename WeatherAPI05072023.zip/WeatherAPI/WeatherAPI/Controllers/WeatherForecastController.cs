﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Models;

namespace WeatherAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherForecastController : ControllerBase
    {
        private ILogger<WeatherForecastController> Logger;
        private readonly IWeatherForecastService WeatherForecastService;
        private readonly AppSettings appSettings;
        public WeatherForecastController(ILogger<WeatherForecastController> logger, IWeatherForecastService weatherForecastService,IOptions<AppSettings> _appsettings)
        {
            Logger = logger;
            WeatherForecastService = weatherForecastService;
            appSettings = _appsettings.Value;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<ActionResult<WeatherForecastModel>> GetWeatherForecastAsync()
        {
            var result = await WeatherForecastService.GetWeatherForecastAllAsync(appSettings.BaseUrl,appSettings.ApiKey,appSettings.URL).ConfigureAwait(false);
            if (result == null)
                return NoContent();
            return Ok(result);
        }

        [HttpPost(Name = "GetWeatherForecastForCity")]
        public async Task<ActionResult<WeatherForecastModel>>GetWeatherForecastForCityAsync(string City)
        {
            var result = await WeatherForecastService.GetWeatherForecastForCityAsync(appSettings.BaseUrl, appSettings.ApiKey, appSettings.URL, City).ConfigureAwait(false);
            if (result == null)
                return NoContent();
            return Ok(result);
        }
    }
}
