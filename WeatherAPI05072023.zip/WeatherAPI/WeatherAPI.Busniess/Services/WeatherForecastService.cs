﻿using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Models;
using WeatherAPI.Repository.Interfaces;

namespace WeatherAPI.Busniess.Services
{
    public class WeatherForecastService : IWeatherForecastService
    {
        private readonly IWeatherForecastRepository WeatherForecastRepository;
        public WeatherForecastService(IWeatherForecastRepository weatherForecastRepository)
        {
            WeatherForecastRepository = weatherForecastRepository ?? throw new ArgumentNullException(nameof(weatherForecastRepository));
        }

        public async Task<WeatherForecastModel> GetWeatherForecastAllAsync(string BaseUrl, string ApiKey, string URL)
        {
            return await WeatherForecastRepository.GetWeatherForecastAllAsync(BaseUrl,ApiKey,URL).ConfigureAwait(false);
        }

        public async Task<WeatherForecastModel> GetWeatherForecastForCityAsync(string BaseUrl, string ApiKey, string URL, string City)
        {
            return await WeatherForecastRepository.GetWeatherForecastForCityAsync(BaseUrl, ApiKey, URL,City).ConfigureAwait(false);
        }
    }
}
