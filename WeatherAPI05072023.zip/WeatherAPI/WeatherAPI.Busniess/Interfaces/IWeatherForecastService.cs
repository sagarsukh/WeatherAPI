﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherAPI.Models;

namespace WeatherAPI.Busniess.Interfaces
{
    public interface IWeatherForecastService
    {
        Task<WeatherForecastModel> GetWeatherForecastAllAsync(string BaseUrl,string ApiKey,string URL);
        Task<WeatherForecastModel> GetWeatherForecastForCityAsync(string BaseUrl, string ApiKey, string URL, string City);
    }
}
