﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Net.Http.Json;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WeatherAPI.Models;

namespace Utility.Common
{
    public static class ConvertJsonToDt
    {
       // static DataSet someDataSet = new DataSet();
       //static DataTable dtmain = new DataTable();
        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    //if (props[i].DisplayName== "main")
                    //{
                    //    dtmain = new DataTable();
                    //    dtmain = JsonStringToDataTable(JsonConvert.SerializeObject(props[i].GetValue(item)));
                       
                    //    //var dta = GetDataTableFromObjects((object[])main);
                    //    //var dt = objToDataTable(mainvalue);
                    //}
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
                //someDataSet.Tables.Add(table);
                //someDataSet.Tables.Add(dtmain);
            }
            return table;
        }

        public static DataTable ToMainDataTable<T>(T data)
        {
            DataTable table = new DataTable();
            string main = JsonConvert.SerializeObject(data);
            table = JsonStringToDataTable(main);
            bool IsCorrectFileHeader = ConvertJsonToDt.ValidateHeaders(table);
            if (IsCorrectFileHeader)
            {
            }
           return table;
        }
       
        public static DataTable JsonStringToDataTable(string jsonString)
        {
            DataTable dt = new DataTable();
            string[] jsonStringArray = Regex.Split(jsonString.Replace("[", "").Replace("]", ""), "},{");
            List<string> ColumnsName = new List<string>();
            foreach (string jSA in jsonStringArray)
            {
                string[] jsonStringData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
                foreach (string ColumnsNameData in jsonStringData)
                {
                    try
                    {
                        int idx = ColumnsNameData.IndexOf(":");
                        string ColumnsNameString = ColumnsNameData.Substring(0, idx - 1).Replace("\"", "");
                        if (!ColumnsName.Contains(ColumnsNameString))
                        {
                            ColumnsName.Add(ColumnsNameString);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(string.Format("Error Parsing Column Name : {0}", ColumnsNameData));
                    }
                }
                break;
            }
            foreach (string AddColumnName in ColumnsName)
            {
                dt.Columns.Add(AddColumnName);
            }
            foreach (string jSA in jsonStringArray)
            {
                string[] RowData = Regex.Split(jSA.Replace("{", "").Replace("}", ""), ",");
                DataRow nr = dt.NewRow();
                foreach (string rowData in RowData)
                {
                    try
                    {
                        int idx = rowData.IndexOf(":");
                        string RowColumns = rowData.Substring(0, idx - 1).Replace("\"", "");
                        string RowDataString = rowData.Substring(idx + 1).Replace("\"", "");
                        nr[RowColumns] = RowDataString;
                    }
                    catch (Exception ex)
                    {
                        continue;
                    }
                }
                dt.Rows.Add(nr);
            }
            return dt;
        }

        private static bool ValidateHeaders(DataTable dataTable)
        {
            bool IsCorrectFileHeader = true;

            var dynamicHeaders = dataTable.Columns.Cast<DataColumn>().Select(x => x.ColumnName?.ToLower()).ToArray();

            List<string> staticHeaders = new List<string>
            {
               "main","feels_like","temp_min","temp_max","pressure","sea_level","grnd_level","humidity","temp_kf","weather","description","icon","clouds","wind","deg","gust","visibility","pop","rain","sys","dt_txt"

            };

            var result = staticHeaders.Where(x1 => !dynamicHeaders.Any(x2 => x1.ToLower().Trim() == x2.Trim()))
                        .Union(dynamicHeaders.Where(x1 => !staticHeaders.Any(x2 => x1.Trim() == x2.ToLower().Trim())));

            IsCorrectFileHeader = result.Count() > 0 ? false : true;

            return IsCorrectFileHeader;
        }

    }


}
