﻿// See https://aka.ms/new-console-template for more information
using Newtonsoft.Json;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Reflection;
using Utility.Common;
string connectionString = ConfigurationManager.ConnectionStrings["WeatherForecast"] != null ? ConfigurationManager.ConnectionStrings["WeatherForecast"].ToString() : string.Empty;
GetGeoLocationData(connectionString).Wait();
static DataTable ExecuteDataSP(string storedprocedureName, string connectionString)
{
    // logger.LogInformation("DBUtility : ExecuteDataSP - Start");
    DataTable dt = new DataTable();
    try
    {
        using (var sqlCon = new SqlConnection(connectionString))
        {
            SqlDataAdapter da = new SqlDataAdapter(storedprocedureName, sqlCon);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.CommandTimeout = 10;
            da.Fill(dt);
            sqlCon.Close();
        }
    }
    catch (Exception ex)
    {
        // logger.LogError("Exception in DBUtility : ExecuteDataSP - ");
        throw ex;
    }
    // logger.LogInformation("DBUtility : ExecuteDataSP - End");
    return dt;
}

static DataTable ExecuteDataMainTableSP(string storedprocedureName, string connectionString,string cityname)
{
    // logger.LogInformation("DBUtility : ExecuteDataSP - Start");
    DataTable dt = new DataTable();
    try
    {
        using (var sqlCon = new SqlConnection(connectionString))
        {
            SqlDataAdapter da = new SqlDataAdapter(storedprocedureName, sqlCon);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.CommandTimeout = 10;
            da.SelectCommand.Parameters.Add("@CityName", SqlDbType.VarChar).Value = cityname;
            da.Fill(dt);
            sqlCon.Close();
        }
    }
    catch (Exception ex)
    {
        // logger.LogError("Exception in DBUtility : ExecuteDataSP - ");
        throw ex;
    }
    // logger.LogInformation("DBUtility : ExecuteDataSP - End");
    return dt;
}

static void InsertIntoIntermediateTable(DataTable data, string connectionString)
{
    try
    {
        var dt = new DataTable();
        dt.Columns.Add("Main", typeof(string));
        dt.Columns.Add("Feels_like", typeof(string));
        dt.Columns.Add("Temp_min", typeof(string));
        dt.Columns.Add("Temp_max", typeof(string));
        dt.Columns.Add("Pressure", typeof(string));
        dt.Columns.Add("Sea_level", typeof(string));
        dt.Columns.Add("Grnd_level", typeof(string));
        dt.Columns.Add("Humidity", typeof(string));
        dt.Columns.Add("Temp_kf", typeof(string));
        dt.Columns.Add("Weather", typeof(string));
        dt.Columns.Add("Description", typeof(string));
        dt.Columns.Add("Icon", typeof(string));
        dt.Columns.Add("Clouds", typeof(string));
        dt.Columns.Add("Wind", typeof(string));
        dt.Columns.Add("Deg", typeof(string));
        dt.Columns.Add("Gust", typeof(string));
        dt.Columns.Add("Visibility", typeof(string));
        dt.Columns.Add("Pop", typeof(string));
        dt.Columns.Add("Rain", typeof(string));
        dt.Columns.Add("Sys", typeof(string));
        dt.Columns.Add("Dt_txt", typeof(string));
        data.AsEnumerable()
                            //.Skip(1) // skip headers
                            .Where(dr => Convert.ToString(dr[0]).Length > 0)
                            .ToList()
                            .ForEach(dr => dt.Rows.Add(dr[0], dr[1], dr[2], dr[3], dr[4], dr[5], dr[6], dr[7], dr[8], dr[9], dr[10],
                                                       dr[11], dr[12], dr[13], dr[14], dr[15], dr[16], dr[17], dr[18], dr[19], dr[20]));

        using (var sqlCon = new SqlConnection(connectionString))
        {
            using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(sqlCon))
            {
                sqlBulkCopy.DestinationTableName = "BulkWeatherUploadIntermediate";
                sqlBulkCopy.ColumnMappings.Add("Main", "Main");
                sqlBulkCopy.ColumnMappings.Add("Feels_like", "Feels_like");
                sqlBulkCopy.ColumnMappings.Add("Temp_min", "Temp_min");
                sqlBulkCopy.ColumnMappings.Add("Temp_max", "Temp_max");
                sqlBulkCopy.ColumnMappings.Add("Pressure", "Pressure");
                sqlBulkCopy.ColumnMappings.Add("Sea_level", "Sea_level");
                sqlBulkCopy.ColumnMappings.Add("Grnd_level", "Grnd_level");
                sqlBulkCopy.ColumnMappings.Add("Humidity", "Humidity");
                sqlBulkCopy.ColumnMappings.Add("Temp_kf", "Temp_kf");
                sqlBulkCopy.ColumnMappings.Add("Weather", "Weather");
                sqlBulkCopy.ColumnMappings.Add("Description", "Description");
                sqlBulkCopy.ColumnMappings.Add("Icon", "Icon");
                sqlBulkCopy.ColumnMappings.Add("Clouds", "Clouds");
                sqlBulkCopy.ColumnMappings.Add("Wind", "Wind");
                sqlBulkCopy.ColumnMappings.Add("Deg", "Deg");
                sqlBulkCopy.ColumnMappings.Add("Gust", "Gust");
                sqlBulkCopy.ColumnMappings.Add("Visibility", "Visibility");
                sqlBulkCopy.ColumnMappings.Add("Pop", "Pop");
                sqlBulkCopy.ColumnMappings.Add("Rain", "Rain");
                sqlBulkCopy.ColumnMappings.Add("Sys", "Sys");
                sqlBulkCopy.ColumnMappings.Add("Dt_txt", "Dt_txt");

                sqlCon.Open();
                sqlBulkCopy.BulkCopyTimeout = 0;
                sqlBulkCopy.WriteToServer(dt);
                sqlCon.Close();
            }
        }
    }
    catch (Exception ex)
    {
        throw ex;
    }
}

static async Task GetGeoLocationData(string connectionString)
{
    HttpClientHandler clientHandler = new HttpClientHandler();
    clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

    using var client = new HttpClient(clientHandler);
    client.BaseAddress = new Uri("https://localhost:7207/");
    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    HttpResponseMessage response = await client.GetAsync("api/IPGeolocation");
    if (response.IsSuccessStatusCode)
    {
        var responseBody = await response.Content.ReadAsStringAsync();
        try
        {
            var geolocation = JsonConvert.DeserializeObject<GeolocationModel>(responseBody);
             GetJsonData(connectionString, geolocation).Wait();
            Console.ReadLine();
        }
        catch (JsonReaderException)
        {
            Console.WriteLine("Something went wrong.");
        }
    }
}
static async Task GetJsonData(string connectionString, GeolocationModel geolocation)
{
    HttpClientHandler clientHandler = new HttpClientHandler();
    clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };

    using var client = new HttpClient(clientHandler);
    client.BaseAddress = new Uri("https://localhost:7207/");
    client.DefaultRequestHeaders.Accept.Clear();
    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

    HttpResponseMessage response = await client.GetAsync($"api/WeatherForecast?latitude={geolocation.latitude}&longitude={geolocation.longitude}");
    if (response.IsSuccessStatusCode)
    {
        var responseBody = await response.Content.ReadAsStringAsync();
        try
        {
            //var songs = JsonConvert.DeserializeObject<List<SongsModel>>(responseBody);
            var weatherForecast = JsonConvert.DeserializeObject<WeatherForecastModel>(responseBody);
            DataTable dt = ConvertJsonToDt.ToMainDataTable(weatherForecast);
            string[] ColumnsToBeDeleted = { "cod", "message", "cnt", "list" };

            foreach (string ColName in ColumnsToBeDeleted)
            {
                if (dt.Columns.Contains(ColName))
                    dt.Columns.Remove(ColName);
            }
            bool IsCorrectFileHeader = ConvertJsonToDt.ValidateHeaders(dt);
            if (IsCorrectFileHeader)
            {
                //Step 1: Clean Bulk Trail IntermediateTable

                ExecuteDataSP("BulkWeather_CleanUp", connectionString);

                //Step 2: Import to BulkTrailUploadIntermediate
                InsertIntoIntermediateTable(dt, connectionString);


                //Step 3: Insert details in MainTable  
                ExecuteDataMainTableSP("BulkWeatherl_Insert", connectionString,geolocation.city_name);
            }
            Console.ReadLine();
        }
        catch (JsonReaderException)
        {
            Console.WriteLine("Something went wrong.");
        }
    }
}


